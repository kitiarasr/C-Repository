#include <iostream>

using namespace std;

enum Colors  //enumerated list. initializes values. Constants?
{
    green =1,
    red = 2,
    yellow = 3
};

void setColors(Colors, Colors);


int main()
{

setColors(red, yellow);






    return 0;
}

void setColors(Colors one, Colors two)
{


    cout << "color one is: " << one << endl;
    cout << "color two is: " << two << endl;
 }
