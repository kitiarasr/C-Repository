﻿using System;

namespace ConsoleApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            Console.WriteLine("Please type in a number to do multiple table: ");
            int num = int.Parse(Console.ReadLine());
            mult(num);
            
        }

        static void mult(int n)
        {

          for(int i = 1; i <= n; i++)
          {

              for(int j = i; j <= n*i; j+=i)
              {            
                  Console.Write(j + " ");
        
              }            
              Console.WriteLine();

          }
             
        }
    }
}
