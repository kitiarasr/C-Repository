
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace hw2

            
{
    //virtual stuff is optional to be overwritten, while abstract stuff HAS to be overridden
//    public abstract void add(); an example of an abstract method. shouldnt include {} because youll be forced to overwrite anyway.
//the point of abstract and virtual is to force user to make sure they have the right implementation of class ( lets say library) to make it work.
//helps make libraries more error prone
            public class Bank
            {
              List <Account> accounts {get; set;}

              public void RemoveAt(int num){}

              public void Add(Account a){}

              public int Count {get;}
   
            }

            public class Account
            {
                private int id {get; set;} 

                public string owner {get; set;}

                public double balance {get; private set;}

                public Account(string o)
                {
                    id++;
                    balance = 0;
                    owner = o;
                }

                public void withdraw (double num) { balance -= num;}
                public void deposit (double num){balance += num;}
            
            
            }
            
            
            public class savingsAccount : Account
            {

               public double balanceSave
               {
                   get
                   {
                        double interest = .015;
                        if(balanceSave > 0)
                        {
                             interest *= balanceSave;
                             return balanceSave += interest;
                        }
                        else
                            return balanceSave;

                   
                   }
                   private set{ balanceSave = balance;}
               }

               public savingsAccount(string o) : base(o){}
            }

            public class checkingAccount : Account
            {
               public checkingAccount(string o) : base(o){}
                  
            }
          

            
    public class Program
    {
        public static void Main(string[] args)
        {
            //make List
             List <Account> Bank = new List<Account>();

             string owner = "";
             bool checking = false;
             bool saving = false;
  

             

           

        while(true)
        {           
             checking = false;
             saving = false;
             Console.WriteLine("What is your name?");
             owner = Console.ReadLine();

             checkingAccount newChecking = new checkingAccount(owner);
             savingsAccount newSaving = new savingsAccount(owner);

             Console.WriteLine("Welcome to the Bank! What would you like to do? \n 1. Make a new checking account, 2. Make a savings account, 3. Delete an account");
             int input =  int.Parse(Console.ReadLine());
            

             switch(input)
             {
                 case 1:
                    Console.WriteLine("making new checking account!.");
                    checking = true;
                    Bank.Add(newChecking);
                  
                    break;
                
                case 2:
                    Console.WriteLine("making new saving account!.");

                    saving = true;
                    Bank.Add(newSaving);

                    break;
              
                case 3:
                    Console.WriteLine("deleting account!" );
                    if(Bank.Count > 0)
                    Bank.RemoveAt(0);
                    else
                        Console.WriteLine("Your bank has no accounts!");

                    break;
            

             }

        
             while(input != 4)
             {

                    Console.WriteLine("Press 1 to deposit, 2 to withdraw, 3 for details on account, 4 to log out of account.");
                    input =  int.Parse(Console.ReadLine());

                    switch(input)
                    {
                        case 1: 
                            if(checking)
                            {
                                newChecking.deposit(50.0);
                                 Console.WriteLine("Value in account is: " + newChecking.balance);
                            }
    
                            else if(saving)
                            {
                                newSaving.deposit(50.0);
                                Console.WriteLine("Value in account is: " + newSaving.balance);
                            }

                  
                        break;
                
                        case 2:
                            if(checking)
                            {
                                newChecking.withdraw(50.0);
                                Console.WriteLine("Value in account is: " + newChecking.balance);

                            }
                            else if(saving)
                            {
                                newChecking.withdraw(50.0);
                                Console.WriteLine("Value in account is: " + newChecking.balance);

                            }
                            break;


                        case 3: //details for account
                            
                          
                             
                           if(checking == true)
                           {
                               Console.WriteLine("Account name: " + newChecking.owner);
                               Console.WriteLine("Checking balance: " + newChecking.balance);
                           }
                           else
                           {
                                Console.WriteLine("Account saving name: " + newSaving.owner);
                                Console.WriteLine("Saving balance: " + newSaving.balance);
                           }

                           if(saving == true && checking == true)
                                 Console.WriteLine("Total balance: " + (newChecking.balance + newSaving.balance));
                           else if(saving == true)
                                 Console.WriteLine("Total balance: " + (newSaving.balance));
                           else
                                 Console.WriteLine("Total balance: " + (newChecking.balance));


                        break;

                      
                    }
            
              }
        }
        

            return;
        }
    
    }
  }
