﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;


// For more information on enabling MVC for empty projects, visit http://go.microsoft.com/fwlink/?LinkID=397860

namespace wildFireProject.Models
{
    public class User
    {
        public int Id{get; set;}
        public string Login{get; set;}
        public string Password {get; set;}
        public string FirstName{get; set;}
        public string lastName{get; set;}
        public List<Idea> Ideas {get; set;}
    }
}
