﻿using System;
//Try parse returns a bool
//parse trys to actually parse
namespace ConsoleApplication
{
    public class Program
    {
        public static void Main(string[] args)
        {
            int length = 0;
            int width = 0;
            int result = 0;

            Console.WriteLine("Please write length: ");
            length = int.Parse(Console.ReadLine());
            Console.WriteLine("Please write width: "); 
            width = int.Parse(Console.ReadLine());

            result = calcRectangle(length, width);
            Console.WriteLine("Rectangle has area of: " + result);
    
        }


        static int calcRectangle(int l, int w)
        {
            return l * w;
        }
    }
}
