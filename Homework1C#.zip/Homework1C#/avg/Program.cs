﻿using System;


// Write 3 functions called Max, Min and Average that each accept an array of integers. Calculate the and return
 // the max, min, and average in the respective functions. Your Average function should not return an integer.
namespace ConsoleApplication
{
    public class Program
    {
  
        public static void Main(string[] args)
        {

            int[] array = new int[10];

            //Array contains numbers 1- 10.
            for(int i = 0; i < array.Length; i++)
                array[i] = i+1;
              
            
            int max= Max(array);
            int min = Min(array);
            double avg = Avg(array);

            Console.WriteLine("Max: " + max);
            Console.WriteLine("Min: " + min);
            Console.WriteLine("Average: " + avg);
        }


        static int Max(int[] array)
        {   
             int highest = 0;  
             highest = array[0];
             for(int i = 0; i < array.Length; i++)
             {
                 if(array[i] > highest)
                    highest = array[i];
             }

             return highest;


        }

       static int Min(int[] array)
       {
            int lowest = 0;  
            lowest = array[0];

            for(int i = 0; i < array.Length; i++)
            {
               if(array[i] < lowest)
                    lowest = array[i];
            }
            
            return lowest;

       }

       static double Avg(int[] array)
       {
          int total = 0;

          for(int i = 0; i < array.Length; i++)
             total += array[i];
    
          return total /= array.Length;

       }
     }
}
