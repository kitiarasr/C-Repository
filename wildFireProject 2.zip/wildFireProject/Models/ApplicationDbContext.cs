using Microsoft.EntityFrameworkCore;


namespace wildFireProject.Models
{

    public class ApplicationDbContext : DbContext
    {
     public DbSet<User> Users {get; set;}
     public DbSet<Idea> Ideas {get; set;}


     protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
     {

            optionsBuilder.UseSqlite("Filename=./wildFireData.db");
     }

    }
}