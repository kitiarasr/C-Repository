﻿
using System.Collections.Generic;
using System.Linq;
using Microsoft.AspNetCore.Mvc;
using wildFireProject.Models;
using Microsoft.EntityFrameworkCore;


namespace wildFireProject.Controllers
{
    public class HomeController : Controller
    {
        private ApplicationDbContext ctx = new ApplicationDbContext();

        public IActionResult Index()
        {
            
            return View();
        }

        public IActionResult Login(string Login, string Password)
        {
            ViewData["Message"] = "Login";

            var model = new wildFireProject.Models.User();
            model.Login = Login;
            model.Password = Password;
            return View("Login", model);
        }

        public IActionResult Register()
        {

            return View();
        }
        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";

            return View();
        }

        public IActionResult Idea(/*info about the idea from the create a project form*/)
        {
            ViewData["Message"] = "Create a Project";
            //statement to add project informaton to database

            return View(/*view page with project info*/"Idea_form");
        }

        public IActionResult IdeaView(string Category, string Title, string Description)
        {
            var model = new wildFireProject.Models.Idea();
            model.Category = Category;
            model.Title = Title;
            model.Description = Description;
            //progress bar

            return View("Idea_view", model);
        }

        public IActionResult Error()
        {
            return View();
        }

        public IActionResult CreateUser()
        {

            var user = new User
            {
                Id = 102,
                FirstName = "Kiti",
                lastName= "Rivera",
                Login = "kitiarasr",
                Password = "soley"
            };

         
       

            var ideaTitles = new List<string>
            {
                "My first project", "my second project"
            };

           var ideas = new List<Idea>(0);

            foreach(var title in ideaTitles)
            {

                var idea = new Idea
                {

                    Title = title,
                    Id = 1,
                    Category = " ",
                    Description = " "

                };

              ideas.Add(idea);
              ctx.Ideas.Add(idea);
              ctx.SaveChanges();
 
          
            }
             user.Ideas = ideas;
            ctx.Users.Add(user);
            ctx.SaveChanges();

            return RedirectToAction("ViewUser");
          }

          public IActionResult ViewUser()
          {

           var user = ctx.Users.Include(c => c.Ideas).FirstOrDefault();
  
              return View(user);
          }
     }
    
}
